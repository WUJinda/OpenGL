Si vous souhaitez exécuter avec succès ce fichier sur votre ordinateur, veuillez ouvrir le terminal de commande ci-dessous. 





<img src="C:\Users\DAREWIN\AppData\Roaming\Typora\typora-user-images\image-20210530190400570.png" alt="image-20210530190400570"  />



Entrez le chemin du fichier actuel avec la commande cd. Utilisez la commande windeplyqt name.exe pour ajouter des dépendances associées. Enfin, ce fichier exe peut être double-cliqué pour l'exécuter.



*Le lien du code source et des fichiers exécutables sur Google drive:*https://drive.google.com/drive/folders/1oqOVW4aXB0ZrXDN2zQuO_mV27xF6vW0U?usp=sharing